#include <types.h>
#include <lib.h>

void hello(void); // prototipo

void hello(void) {
  kprintf("Hello from me!\n");
}
