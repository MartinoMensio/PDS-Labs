/*
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2008, 2009
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <types.h>
#include <clock.h>
#include <copyinout.h>
#include <syscall.h>
#include <kern/errno.h>
#include <kern/unistd.h>
#include <types.h>
#include <lib.h>
#include <syscall.h>

/*
 * Example system call: get the time of day.
 */
/*int
sys___time(userptr_t user_seconds_ptr, userptr_t user_nanoseconds_ptr)
{
	struct timespec ts;
	int result;

	gettime(&ts);

	result = copyout(&ts.tv_sec, user_seconds_ptr, sizeof(ts.tv_sec));
	if (result) {
		return result;
	}

	result = copyout(&ts.tv_nsec, user_nanoseconds_ptr,
			 sizeof(ts.tv_nsec));
	if (result) {
		return result;
	}

	return 0;
}*/
ssize_t sys_write(int fd, const void *buf, size_t nbytes) {
  //TODO
  (void)fd;
  if(buf == NULL) {
    // no data to write
    return -1;
  }
  char* temp_buffer=kmalloc(sizeof(char)*(nbytes+1));
  if (temp_buffer == NULL) {
    // no space for malloc
    return -1;
  }
  //copy to my buffer
  copyin((const_userptr_t)buf,temp_buffer,nbytes);

  // terminate the string
  temp_buffer[nbytes]='\0';

  // print using kprintf
  kprintf("%s",temp_buffer);

	return nbytes;
}

ssize_t sys_read(int fd, const void *buf, size_t buflen) {
  (void)fd;
  int result;
 
  if (!buflen)
    return 0;
  if(buf == NULL) {
    // no buffer to store data
    return -1;
  }
  //Create a temporary array in the kernel to store buffer
  char* temp_buffer=kmalloc((buflen+1)*sizeof(char));

  if (temp_buffer == NULL) {
    // no space for malloc
    return -1;
  }
  // read from STDIN  

  size_t i;
  for(i = 0;i<buflen; i++ ){
    // TODO need to test that
	  temp_buffer[i] = getch();
  }
  temp_buffer[buflen] = '\0';

  //kgets(temp_buffer, buflen);


  //copy stored input to the user buffer
  result = copyout(temp_buffer,(userptr_t)buf,sizeof(buf));

  return result;
}
